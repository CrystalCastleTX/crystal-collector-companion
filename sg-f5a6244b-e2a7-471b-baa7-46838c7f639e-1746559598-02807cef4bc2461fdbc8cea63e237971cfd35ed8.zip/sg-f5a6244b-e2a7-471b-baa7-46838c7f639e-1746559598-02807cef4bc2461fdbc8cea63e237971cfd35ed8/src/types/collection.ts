export interface Specimen {
  id: string;
  mineralName: string;
  locality?: string;
  acquisitionDate?: string;
  photos: string[];
  pricePaid?: number;
  estimatedValue?: number;
  notes?: string;
  mindatMineralLink?: string;
  mindatLocalityLink?: string;
  createdAt: string;
  updatedAt: string;
  collectionId: string;
}

export interface Collection {
  id: string;
  name: string;
  description?: string;
  parentId?: string;
  specimens: string[]; // Array of specimen IDs
  subCollections: string[]; // Array of sub-collection IDs
  lastUpdated: string;
  userId: string;
}

export interface User {
  id: string;
  email: string;
  name?: string;
  photoURL?: string;
}
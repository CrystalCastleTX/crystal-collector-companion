
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { useState, useRef } from "react";
import { Specimen } from "@/types/collection";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Camera, Upload, X } from "lucide-react";
import { cn } from "@/lib/utils";
import Image from "next/image";

interface SpecimenFormProps {
  specimen?: Specimen;
  onSave: (specimen: Partial<Specimen>) => void;
}

export function SpecimenForm({ specimen, onSave }: SpecimenFormProps) {
  const [mineralName, setMineralName] = useState(specimen?.mineralName || "");
  const [locality, setLocality] = useState(specimen?.locality || "");
  const [acquisitionDate, setAcquisitionDate] = useState<Date | undefined>(
    specimen?.acquisitionDate ? new Date(specimen.acquisitionDate) : undefined
  );
  const [pricePaid, setPricePaid] = useState(specimen?.pricePaid?.toString() || "");
  const [estimatedValue, setEstimatedValue] = useState(specimen?.estimatedValue?.toString() || "");
  const [notes, setNotes] = useState(specimen?.notes || "");
  const [mindatMineralLink, setMindatMineralLink] = useState(specimen?.mindatMineralLink || "");
  const [mindatLocalityLink, setMindatLocalityLink] = useState(specimen?.mindatLocalityLink || "");
  const [photos, setPhotos] = useState<string[]>(specimen?.photos || []);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const newPhotos = Array.from(files).map(file => URL.createObjectURL(file));
      setPhotos(prev => [...prev, ...newPhotos].slice(0, 3));
    }
  };

  const handleCameraCapture = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const newPhotos = Array.from(files).map(file => URL.createObjectURL(file));
      setPhotos(prev => [...prev, ...newPhotos].slice(0, 3));
    }
  };

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const specimenData: Partial<Specimen> = {
      mineralName,
      locality: locality || undefined,
      acquisitionDate: acquisitionDate ? format(acquisitionDate, "yyyy-MM-dd") : undefined,
      photos,
      pricePaid: pricePaid ? parseFloat(pricePaid) : undefined,
      estimatedValue: estimatedValue ? parseFloat(estimatedValue) : undefined,
      notes: notes || undefined,
      mindatMineralLink: mindatMineralLink || undefined,
      mindatLocalityLink: mindatLocalityLink || undefined,
    };
    
    onSave(specimenData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardContent className="p-6 space-y-6">
          <div className="space-y-2">
            <Label htmlFor="mineralName">Mineral Name *</Label>
            <Input
              id="mineralName"
              value={mineralName}
              onChange={(e) => setMineralName(e.target.value)}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="locality">Locality</Label>
            <Input
              id="locality"
              value={locality}
              onChange={(e) => setLocality(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="acquisitionDate">Acquisition Date</Label>
            <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !acquisitionDate && "text-muted-foreground"
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {acquisitionDate ? format(acquisitionDate, "PPP") : "Select a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={acquisitionDate}
                  onSelect={(date) => {
                    setAcquisitionDate(date);
                    setIsCalendarOpen(false);
                  }}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="pricePaid">Price Paid ($)</Label>
              <Input
                id="pricePaid"
                type="number"
                step="0.01"
                min="0"
                value={pricePaid}
                onChange={(e) => setPricePaid(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="estimatedValue">Estimated Value ($)</Label>
              <Input
                id="estimatedValue"
                type="number"
                step="0.01"
                min="0"
                value={estimatedValue}
                onChange={(e) => setEstimatedValue(e.target.value)}
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="mindatMineralLink">Mindat.org Mineral Link</Label>
            <Input
              id="mindatMineralLink"
              type="url"
              value={mindatMineralLink}
              onChange={(e) => setMindatMineralLink(e.target.value)}
              placeholder="https://www.mindat.org/min-198.html"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="mindatLocalityLink">Mindat.org Locality Link</Label>
            <Input
              id="mindatLocalityLink"
              type="url"
              value={mindatLocalityLink}
              onChange={(e) => setMindatLocalityLink(e.target.value)}
              placeholder="https://www.mindat.org/loc-3523.html"
            />
          </div>
          
          <div className="space-y-2">
            <Label>Photos</Label>
            <div className="border border-input rounded-md p-4">
              <div className="grid grid-cols-3 gap-4 mb-4">
                {photos.map((photo, index) => (
                  <div key={index} className="relative aspect-square">
                    <Image
                      src={photo}
                      alt={`Specimen photo ${index + 1}`}
                      fill
                      className="object-cover rounded-md"
                    />
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-1 right-1 h-6 w-6"
                      onClick={() => removePhoto(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
              
              {photos.length < 3 && (
                <div className="flex flex-wrap gap-2">
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    multiple={3 - photos.length > 1}
                  />
                  <input
                    type="file"
                    accept="image/*"
                    capture="environment"
                    className="hidden"
                    ref={cameraInputRef}
                    onChange={handleCameraCapture}
                  />
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Photo
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => cameraInputRef.current?.click()}
                  >
                    <Camera className="h-4 w-4 mr-2" />
                    Take Photo
                  </Button>
                </div>
              )}
              <p className="text-xs text-muted-foreground mt-2">
                Upload up to 3 photos of your specimen
              </p>
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => window.history.back()}>
              Cancel
            </Button>
            <Button type="submit" className="bg-accent text-white hover:bg-accent/90">
              Save Specimen
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
}

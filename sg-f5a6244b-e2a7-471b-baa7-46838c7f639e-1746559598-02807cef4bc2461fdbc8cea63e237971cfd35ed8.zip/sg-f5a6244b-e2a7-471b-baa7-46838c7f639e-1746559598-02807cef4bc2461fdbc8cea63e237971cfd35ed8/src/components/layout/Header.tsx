
import { Button } from "@/components/ui/button";
import Image from "next/image";
import Link from "next/link";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";
import { SocialLinks } from "@/components/layout/SocialLinks";

export function Header() {
  return (
    <header className="bg-primary">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Sign in button on the left */}
        <Button className="bg-accent text-white">Sign In</Button>
        
        {/* Centered logo and title */}
        <div className="absolute left-1/2 transform -translate-x-1/2 flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2 no-underline">
            <Image
              src="/cc-logocirclew-05in300dpi-macx7ngh.png"
              alt="Crystal Castle Logo"
              width={40}
              height={40}
              className="object-contain"
            />
            <h1 className="text-2xl font-bold text-white hidden sm:block">Collector&apos;s Companion</h1>
            <h1 className="text-lg font-bold text-white sm:hidden">Collector&apos;s</h1>
          </Link>
        </div>
        
        {/* Menu button on the right for all screen sizes */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="text-white">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent className="bg-primary text-white overflow-y-auto max-h-screen">
            <div className="flex flex-col gap-4 mt-8">
              <nav className="flex flex-col w-full space-y-2">
                <Link href="/">
                  <Button variant="ghost" className="w-full justify-start text-white hover:text-white/90">Home</Button>
                </Link>
                <Link href="/collection">
                  <Button variant="ghost" className="w-full justify-start text-white hover:text-white/90">My Collection</Button>
                </Link>
                <Link href="/specimens/add">
                  <Button variant="ghost" className="w-full justify-start text-white hover:text-white/90">Add Specimen</Button>
                </Link>
                <Link href="/meet-the-prospector">
                  <Button variant="ghost" className="w-full justify-start text-white hover:text-white/90">Meet the Prospector</Button>
                </Link>
                <Link href="/about">
                  <Button variant="ghost" className="w-full justify-start text-white hover:text-white/90">Learn More</Button>
                </Link>
                <Link href="/settings">
                  <Button variant="ghost" className="w-full justify-start text-white hover:text-white/90">Settings</Button>
                </Link>
              </nav>
              
              <Button className="mt-2 bg-accent text-white">Sign In</Button>
              
              <div className="mt-6 pt-4 border-t border-white/20">
                <p className="text-sm text-white/70 mb-3">Connect with us:</p>
                <div className="flex flex-col space-y-3">
                  <SocialLinks showLabels={true} className="flex-col space-y-3" />
                </div>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}

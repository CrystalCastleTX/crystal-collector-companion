
import { Facebook, Globe, MessageSquare, Video } from "lucide-react";
import Link from "next/link";

interface SocialLinksProps {
  className?: string;
  showLabels?: boolean;
}

export function SocialLinks({ className, showLabels = true }: SocialLinksProps) {
  return (
    <div className={`flex ${className || "items-center gap-4"}`}>
      <Link 
        href="https://crystalcastle.rocks/" 
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 text-white hover:text-white/90 transition-colors underline"
        aria-label="Crystal Castle Website"
      >
        <Globe size={20} />
        {showLabels && <span>Website</span>}
      </Link>
      
      <Link 
        href="https://www.facebook.com/groups/crystalcastletx" 
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 text-white hover:text-white/90 transition-colors underline"
        aria-label="Crystal Castle Collectors Facebook Group"
      >
        <Facebook size={20} />
        {showLabels && <span>Facebook</span>}
      </Link>
      
      <Link 
        href="https://www.tiktok.com/@crystalcastletx" 
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 text-white hover:text-white/90 transition-colors underline"
        aria-label="Crystal Castle TikTok"
      >
        <Video size={20} />
        {showLabels && <span>TikTok</span>}
      </Link>
      
      <Link 
        href="https://widget.smsinfo.io/v2/8f57e5261a9c24df5ccce51848bcb2e3?st-lid=14595688" 
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 text-white hover:text-white/90 transition-colors underline"
        aria-label="Sign up for text alerts"
      >
        <MessageSquare size={20} />
        {showLabels && <span>Text Alerts</span>}
      </Link>
    </div>
  );
}

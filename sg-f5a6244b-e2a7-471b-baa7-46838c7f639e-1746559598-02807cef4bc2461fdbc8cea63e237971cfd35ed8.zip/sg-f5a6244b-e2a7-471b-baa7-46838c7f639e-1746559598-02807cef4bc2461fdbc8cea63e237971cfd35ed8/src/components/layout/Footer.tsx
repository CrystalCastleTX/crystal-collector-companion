
import { SocialLinks } from "@/components/layout/SocialLinks";

export function Footer() {
  return (
    <footer className="bg-accent text-white py-6 mt-auto">
      <div className="container mx-auto px-4">
        <div className="flex flex-col gap-4">
          <div className="flex justify-center md:justify-start">
            <SocialLinks className="flex-wrap justify-center md:justify-start gap-4" />
          </div>
          
          <div className="text-sm text-center md:text-left">
            © {new Date().getFullYear()} Crystal Castle TX. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}

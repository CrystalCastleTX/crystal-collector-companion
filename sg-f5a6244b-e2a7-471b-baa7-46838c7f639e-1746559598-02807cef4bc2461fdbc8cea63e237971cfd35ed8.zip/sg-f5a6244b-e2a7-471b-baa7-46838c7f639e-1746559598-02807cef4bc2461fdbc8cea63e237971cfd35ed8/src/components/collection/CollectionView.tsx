
import { Specimen } from "@/types/collection";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Edit, Folder, FolderPlus, MoreHorizontal, Share2, Trash2 } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import Link from "next/link";
import Image from "next/image";
import { ShareButtons } from "@/components/sharing/ShareButtons";
import { toast } from "@/hooks/use-toast";

interface CollectionViewProps {
  specimens: Specimen[];
  onExport?: () => void;
  className?: string;
  collectionName?: string;
  onRenameCollection?: (name: string) => void;
  onCreateSubCollection?: (name: string) => void;
}

export function CollectionView({ 
  specimens, 
  onExport, 
  className, 
  collectionName = "Your Collection",
  onRenameCollection,
  onCreateSubCollection
}: CollectionViewProps) {
  const [view, setView] = useState<"gallery" | "list">("gallery");
  const [isRenaming, setIsRenaming] = useState(false);
  const [newName, setNewName] = useState(collectionName);
  const [isCreatingSubCollection, setIsCreatingSubCollection] = useState(false);
  const [subCollectionName, setSubCollectionName] = useState("");

  const handleExport = () => {
    if (onExport) {
      onExport();
    }
  };

  const handleRenameSubmit = () => {
    if (onRenameCollection && newName.trim()) {
      onRenameCollection(newName);
    }
    setIsRenaming(false);
  };

  const handleCreateSubCollection = () => {
    if (onCreateSubCollection && subCollectionName.trim()) {
      onCreateSubCollection(subCollectionName);
      setSubCollectionName("");
    }
    setIsCreatingSubCollection(false);
  };

  const handleDelete = (id: string) => {
    if (window.confirm("Are you sure you want to delete this specimen? This action cannot be undone.")) {
      console.log("Deleting specimen:", id);
      toast({
        title: "Specimen deleted",
        description: "The specimen has been removed from your collection.",
      });
    }
  };

  return (
    <div className={className}>
      <div className="flex flex-col gap-4 mb-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          {isRenaming ? (
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Input
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="max-w-xs"
                autoFocus
              />
              <Button onClick={handleRenameSubmit} size="sm" className="bg-accent text-white hover:bg-accent/90">Save</Button>
              <Button 
                onClick={() => {
                  setIsRenaming(false);
                  setNewName(collectionName);
                }} 
                variant="outline" 
                size="sm"
              >
                Cancel
              </Button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-bold">{collectionName}</h2>
              {onRenameCollection && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setIsRenaming(true)}
                  className="h-8 w-8 p-0"
                >
                  <Edit className="h-4 w-4" />
                </Button>
              )}
            </div>
          )}
          
          <div className="flex flex-wrap gap-2">
            <Tabs defaultValue={view} onValueChange={(v) => setView(v as "gallery" | "list")}>
              <TabsList>
                <TabsTrigger value="gallery">Gallery</TabsTrigger>
                <TabsTrigger value="list">List</TabsTrigger>
              </TabsList>
            </Tabs>
            <ShareButtons 
              title={collectionName}
              description={`A collection of ${specimens.length} crystal specimens`}
              url={typeof window !== "undefined" ? window.location.href : ""}
              type="collection"
            />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="bg-accent text-white hover:bg-accent/90">
                  <MoreHorizontal className="h-4 w-4 mr-2" />
                  Actions
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => setIsCreatingSubCollection(true)}>
                  <FolderPlus className="h-4 w-4 mr-2" />
                  Create Sub-Collection
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExport}>
                  Export Collection
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {isCreatingSubCollection && (
          <div className="flex items-center gap-2 p-4 bg-muted rounded-md">
            <Folder className="h-5 w-5 text-muted-foreground" />
            <Input
              value={subCollectionName}
              onChange={(e) => setSubCollectionName(e.target.value)}
              placeholder="New Sub-Collection Name"
              className="max-w-xs"
              autoFocus
            />
            <Button onClick={handleCreateSubCollection} size="sm" className="bg-accent text-white hover:bg-accent/90">Create</Button>
            <Button 
              onClick={() => {
                setIsCreatingSubCollection(false);
                setSubCollectionName("");
              }} 
              variant="outline" 
              size="sm"
            >
              Cancel
            </Button>
          </div>
        )}
      </div>

      {view === "gallery" && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {specimens.map((specimen) => (
            <Card key={specimen.id} className="h-full hover:shadow-md transition-shadow">
              <div className="aspect-square relative">
                {specimen.photos.length > 0 ? (
                  <Image 
                    src={specimen.photos[0]} 
                    alt={specimen.mineralName}
                    fill
                    className="object-cover rounded-t-lg"
                  />
                ) : (
                  <div className="w-full h-full bg-muted flex items-center justify-center">
                    <p className="text-muted-foreground">No image</p>
                  </div>
                )}
              </div>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start">
                  <CardTitle>{specimen.mineralName}</CardTitle>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link href={`/specimens/${specimen.id}`}>
                          View Details
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href={`/specimens/edit/${specimen.id}`}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-destructive" 
                        onClick={() => handleDelete(specimen.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="pb-4">
                {specimen.locality && (
                  <p className="text-muted-foreground text-sm">Location: {specimen.locality}</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {view === "list" && (
        <div className="space-y-4">
          {specimens.map((specimen) => (
            <Card key={specimen.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 relative flex-shrink-0">
                    {specimen.photos.length > 0 ? (
                      <Image 
                        src={specimen.photos[0]} 
                        alt={specimen.mineralName}
                        fill
                        className="object-cover rounded-md"
                      />
                    ) : (
                      <div className="w-full h-full bg-muted flex items-center justify-center rounded-md">
                        <p className="text-muted-foreground text-xs">No image</p>
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold">{specimen.mineralName}</h3>
                        {specimen.locality && (
                          <p className="text-muted-foreground text-sm">Location: {specimen.locality}</p>
                        )}
                        {specimen.acquisitionDate && (
                          <p className="text-muted-foreground text-sm">
                            Acquired: {new Date(specimen.acquisitionDate).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem asChild>
                            <Link href={`/specimens/${specimen.id}`}>
                              View Details
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <Link href={`/specimens/edit/${specimen.id}`}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            className="text-destructive" 
                            onClick={() => handleDelete(specimen.id)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                  {specimen.estimatedValue !== undefined && (
                    <div className="text-sm font-medium">
                      ${specimen.estimatedValue.toFixed(2)}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

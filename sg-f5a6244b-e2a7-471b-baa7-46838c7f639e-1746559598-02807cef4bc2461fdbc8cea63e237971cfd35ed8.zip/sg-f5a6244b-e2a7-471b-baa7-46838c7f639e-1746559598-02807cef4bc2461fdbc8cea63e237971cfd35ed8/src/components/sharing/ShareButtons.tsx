
import { 
  Facebook, 
  Twitter, 
  Mail, 
  Link as LinkIcon, 
  Share2 
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Prospector } from "@/components/mascot/Prospector";

interface ShareButtonsProps {
  title: string;
  description?: string;
  url: string;
  type: "collection" | "specimen";
  className?: string;
}

export function ShareButtons({ title, description, url, type, className }: ShareButtonsProps) {
  const [showShareSuccess, setShowShareSuccess] = useState(false);
  const { toast } = useToast();
  
  // Format the share text based on type
  const shareText = type === "collection" 
    ? `Check out my crystal collection: ${title}`
    : `Check out this amazing ${title} specimen in my collection!`;
  
  const encodedText = encodeURIComponent(shareText);
  const encodedUrl = encodeURIComponent(url);
  
  const facebookGroupUrl = "https://www.facebook.com/groups/crystalcastletx";
  const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedText}`;
  const twitterShareUrl = `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`;
  const emailSubject = encodeURIComponent(type === "collection" ? "My Crystal Collection" : `${title} Specimen`);
  const emailBody = encodeURIComponent(`${shareText}\n\n${url}`);
  const emailShareUrl = `mailto:?subject=${emailSubject}&body=${emailBody}`;
  
  const handleCopyLink = () => {
    navigator.clipboard.writeText(url).then(() => {
      toast({
        title: "Link copied!",
        description: "The link has been copied to your clipboard."
      });
    });
  };
  
  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: title,
        text: shareText,
        url: url,
      })
      .then(() => {
        setShowShareSuccess(true);
        setTimeout(() => setShowShareSuccess(false), 5000);
      })
      .catch((error) => console.log('Error sharing', error));
    } else {
      handleCopyLink();
    }
  };

  return (
    <div className={className}>
      {showShareSuccess && (
        <Prospector 
          message="Showing off your stash? You fancy now!" 
          category="export"
          className="mb-4"
        />
      )}
      
      {/* Native share button for mobile */}
      <div className="sm:hidden">
        <Button onClick={handleShare} variant="outline" className="w-full">
          <Share2 className="h-4 w-4 mr-2" />
          Share
        </Button>
      </div>
      
      {/* Dropdown for desktop */}
      <div className="hidden sm:block">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline">
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem asChild>
              <a 
                href={facebookShareUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center"
              >
                <Facebook className="h-4 w-4 mr-2" />
                Share on Facebook
              </a>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <a 
                href={facebookGroupUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center"
              >
                <Facebook className="h-4 w-4 mr-2" />
                Share in Crystal Castle Group
              </a>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <a 
                href={twitterShareUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center"
              >
                <Twitter className="h-4 w-4 mr-2" />
                Share on Twitter
              </a>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <a 
                href={emailShareUrl}
                className="flex items-center"
              >
                <Mail className="h-4 w-4 mr-2" />
                Share via Email
              </a>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleCopyLink}>
              <LinkIcon className="h-4 w-4 mr-2" />
              Copy Link
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

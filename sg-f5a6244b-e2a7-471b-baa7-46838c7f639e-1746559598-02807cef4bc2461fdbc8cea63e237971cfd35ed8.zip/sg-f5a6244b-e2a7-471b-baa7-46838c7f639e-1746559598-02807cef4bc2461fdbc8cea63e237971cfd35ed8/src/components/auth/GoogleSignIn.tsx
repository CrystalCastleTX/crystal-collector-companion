import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { authService } from "@/services/auth";

interface GoogleSignInProps {
  onSignIn: (user: any) => void;
  className?: string;
}

export function GoogleSignIn({ onSignIn, className }: GoogleSignInProps) {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    
    // For demo purposes, simulate a successful sign-in with mock data
    const mockUser = {
      id: "user1",
      email: "demo@example.com",
      name: "Demo User",
      photoURL: "https://via.placeholder.com/150"
    };
    
    // Uncomment to auto-sign in for testing
    // onSignIn(mockUser);
  }, []);

  const handleSignIn = async () => {
    try {
      // For demo purposes, simulate a successful sign-in with mock data
      const mockUser = {
        id: "user1",
        email: "demo@example.com",
        name: "Demo User",
        photoURL: "https://via.placeholder.com/150"
      };
      
      onSignIn(mockUser);
      
      // In production, we would use:
      // await authService.signInWithGoogle();
    } catch (error) {
      console.error('Error signing in with Google:', error);
    }
  };

  if (!isClient) return null;

  return (
    <Button 
      onClick={handleSignIn}
      className={`bg-accent text-white hover:bg-accent/90 ${className}`}
      size="lg"
    >
      Sign in with Google
    </Button>
  );
}
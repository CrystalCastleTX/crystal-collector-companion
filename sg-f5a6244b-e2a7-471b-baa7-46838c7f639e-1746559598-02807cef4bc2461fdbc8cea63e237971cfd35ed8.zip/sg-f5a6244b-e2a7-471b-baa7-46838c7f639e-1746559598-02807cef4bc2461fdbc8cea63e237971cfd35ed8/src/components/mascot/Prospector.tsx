
import { cn } from "@/lib/utils";
import { MessageCategory, getRandomMessage } from "@/lib/prospector-messages";
import Image from "next/image";
import { useEffect, useState } from "react";

interface ProspectorProps {
  message?: string;
  category?: MessageCategory;
  className?: string;
}

export function Prospector({ message, category = "launch", className }: ProspectorProps) {
  const [displayMessage, setDisplayMessage] = useState(message);

  useEffect(() => {
    if (!message && category) {
      setDisplayMessage(getRandomMessage(category));
    }
  }, [message, category]);

  return (
    <div className={cn("flex items-start gap-4 p-4 bg-muted rounded-lg", className)}>
      <div className="w-16 h-16 rounded-full overflow-hidden flex-shrink-0">
        <Image
          src="/chatgpt-image-apr-23-2025-05-12-36-pm-macxbkyw.png"
          alt="The Prospector"
          width={64}
          height={64}
          className="object-cover"
        />
      </div>
      <div className="flex-1">
        <p className="text-foreground text-lg">{displayMessage}</p>
      </div>
    </div>
  );
}

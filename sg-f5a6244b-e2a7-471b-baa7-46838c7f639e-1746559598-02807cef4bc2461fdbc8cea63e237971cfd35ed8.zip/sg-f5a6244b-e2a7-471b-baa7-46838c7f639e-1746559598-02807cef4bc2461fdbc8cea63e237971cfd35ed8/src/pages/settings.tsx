import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

export default function SettingsPage() {
  const [showProspector, setShowProspector] = useState(true);
  const [openMindatExternally, setOpenMindatExternally] = useState(false);
  const [theme, setTheme] = useState("classic");

  useEffect(() => {
    // Get saved theme from localStorage or default to "classic"
    const savedTheme = localStorage.getItem("theme") || "classic";
    setTheme(savedTheme);
    document.documentElement.setAttribute("data-theme", savedTheme);
  }, []);

  const handleThemeChange = (value: string) => {
    setTheme(value);
    localStorage.setItem("theme", value);
    document.documentElement.setAttribute("data-theme", value);
  };

  const handleClearData = () => {
    // This will be implemented when we connect to Supabase
    console.log("Clear all data");
  };

  const handleExportData = () => {
    // This will be implemented when we connect to Supabase
    console.log("Export data");
  };

  return (
    <>
      <Head>
        <title>Settings | Crystal Collector&apos;s Companion</title>
        <meta name="description" content="Manage your app settings" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <h2 className="text-3xl font-bold mb-6">Settings</h2>
          
          <div className="max-w-2xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Theme</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={theme} onValueChange={handleThemeChange}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="classic" id="classic" />
                    <Label htmlFor="classic">Classic (Purple)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="light" id="light" />
                    <Label htmlFor="light">Light</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dark" id="dark" />
                    <Label htmlFor="dark">Dark</Label>
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>App Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-prospector">Show The Prospector</Label>
                  <Switch 
                    id="show-prospector" 
                    checked={showProspector} 
                    onCheckedChange={setShowProspector} 
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <Label htmlFor="open-mindat">Open Mindat.org links in external browser</Label>
                  <Switch 
                    id="open-mindat" 
                    checked={openMindatExternally} 
                    onCheckedChange={setOpenMindatExternally} 
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Data Management</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-muted-foreground mb-2">Export your collection data as a JSON file</p>
                  <Button onClick={handleExportData}>Export Data</Button>
                </div>
                
                <Separator />
                
                <div>
                  <p className="text-muted-foreground mb-2">Clear all collection data from this device</p>
                  <Button variant="destructive" onClick={handleClearData}>Clear All Data</Button>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>About</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Crystal Collector&apos;s Companion v1.0</p>
                <p className="text-muted-foreground">© 2025 Crystal Castle TX</p>
                <p className="mt-2">
                  <a 
                    href="https://www.crystalcastle.rocks" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-foreground hover:underline"
                  >
                    Visit Crystal Castle TX
                  </a>
                </p>
              </CardContent>
            </Card>
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}
import { Header } from "@/components/layout/Header";
import { Prospector } from "@/components/mascot/Prospector";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { Card, CardContent } from "@/components/ui/card";
import Image from "next/image";

export default function AboutPage() {
  return (
    <>
      <Head>
        <title>About | Crystal Collector&apos;s Companion</title>
        <meta name="description" content="Learn more about the Crystal Collector's Companion app" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">About Crystal Collector&apos;s Companion</h2>
            
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="flex flex-col items-center mb-6">
                  <Image
                    src="/cc-logocirclew-05in300dpi-macx7ngh.png"
                    alt="Crystal Castle Logo"
                    width={120}
                    height={120}
                    className="object-contain mb-4"
                  />
                  <h3 className="text-2xl font-bold">Crystal Castle TX</h3>
                </div>
                
                <div className="space-y-4">
                  <p>
                    Crystal Collector&apos;s Companion is a digital tool designed for mineral enthusiasts 
                    to catalog, organize, and manage their personal fine mineral collections.
                  </p>
                  
                  <p>
                    With this app, you can:
                  </p>
                  
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Log detailed information about each specimen in your collection</li>
                    <li>Upload photos to document your specimens</li>
                    <li>Track acquisition dates, localities, and values</li>
                    <li>Link to Mindat.org for reference information</li>
                    <li>Export your collection data for backup or sharing</li>
                    <li>View your collection in gallery or list format</li>
                  </ul>
                  
                  <p>
                    All your data is stored locally on your device, ensuring your collection 
                    information remains private and accessible even without an internet connection.
                  </p>
                  
                  <p>
                    Crystal Collector&apos;s Companion is developed by Crystal Castle TX, 
                    a premier source for fine minerals and crystals.
                  </p>
                  
                  <div className="mt-6 pt-4 border-t border-border">
                    <h3 className="text-xl font-semibold mb-4">Connect with us</h3>
                    <div className="space-y-3">
                      <p>
                        <a 
                          href="https://www.crystalcastle.rocks" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-foreground hover:text-foreground/90 underline decoration-solid"
                        >
                          Visit our website
                        </a> to explore our selection of minerals and crystals.
                      </p>
                      
                      <p>
                        Join our <a 
                          href="https://www.facebook.com/groups/crystalcastletx"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-foreground hover:text-foreground/90 underline decoration-solid"
                        >
                          Facebook group
                        </a> to connect with other crystal enthusiasts.
                      </p>
                      
                      <p>
                        Follow us on <a 
                          href="https://www.tiktok.com/@crystalcastletx"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-foreground hover:text-foreground/90 underline decoration-solid"
                        >
                          TikTok
                        </a> for videos and updates.
                      </p>
                      
                      <p>
                        <a 
                          href="https://widget.smsinfo.io/v2/8f57e5261a9c24df5ccce51848bcb2e3?st-lid=14595688"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-foreground hover:text-foreground/90 underline decoration-solid"
                        >
                          Sign up for text alerts
                        </a> to receive notifications about new specimens and events.
                      </p>
                    </div>
                  </div>
                  
                  <div className="mt-6 pt-4 border-t border-border">
                    <h3 className="text-xl font-semibold mb-4">Join Our Community</h3>
                    <p>
                      Don't miss our exciting live sales on TikTok where we showcase unique and rare specimens! Our vibrant Facebook community offers special sales and connects you with fellow collectors who share your passion for minerals and crystals.
                    </p>
                    <p className="mt-3">
                      Sign up for our text alerts to stay informed about upcoming sales, new inventory, and special events. Be the first to know when exceptional pieces become available and join our growing community of dedicated collectors!
                    </p>
                    <p className="mt-6 text-lg italic">
                      -Devyn and Morgan Overton, Your new mineral collecting friends
                    </p>
                  </div>

                  <div className="relative w-full h-[400px] mt-8 rounded-lg overflow-hidden">
                    <Image
                      src="/screenshot-2025-05-06-160114-mad1fbxg.png"
                      alt="Crystal Castle Team"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Prospector 
              message="Every specimen's got a story. Yours? Might just be a bestseller."
              className="mt-8"
            />
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}
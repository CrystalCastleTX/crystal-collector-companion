
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { testSupabaseConnection, testCreateCollection, testCreateSpecimen } from "@/utils/supabase-test";
import { Prospector } from "@/components/mascot/Prospector";
import { toast } from "@/hooks/use-toast";

export default function SupabaseTestPage() {
  const [isConnected, setIsConnected] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [testResults, setTestResults] = useState<string[]>([]);

  useEffect(() => {
    // Check connection on page load
    checkConnection();
  }, []);

  const checkConnection = async () => {
    setIsLoading(true);
    try {
      const connected = await testSupabaseConnection();
      setIsConnected(connected);
      setTestResults(prev => [...prev, `Connection test: ${connected ? 'Success' : 'Failed'}`]);
    } catch (error) {
      console.error('Error testing connection:', error);
      setIsConnected(false);
      setTestResults(prev => [...prev, `Connection test error: ${error instanceof Error ? error.message : String(error)}`]);
    } finally {
      setIsLoading(false);
    }
  };

  const runCreateTests = async () => {
    setIsLoading(true);
    setTestResults(prev => [...prev, "Starting CRUD tests..."]);
    
    try {
      // Use a test user ID
      const testUserId = "test-user-id";
      
      // Test creating a collection
      const collection = await testCreateCollection(testUserId);
      if (collection) {
        setTestResults(prev => [...prev, `Created test collection: ${collection.name}`]);
        
        // Test creating a specimen in that collection
        if (collection.id) {
          const specimen = await testCreateSpecimen(collection.id, testUserId);
          if (specimen) {
            // Handle snake_case to camelCase conversion
            const mineralName = typeof specimen === 'object' && specimen !== null 
              ? (specimen.mineralName || (specimen as any).mineral_name || 'Unknown')
              : 'Unknown';
              
            setTestResults(prev => [...prev, `Created test specimen: ${mineralName}`]);
          }
        }
      }
      
      toast({
        title: "Tests completed",
        description: "All Supabase tests completed successfully",
      });
    } catch (error) {
      console.error('Error running CRUD tests:', error);
      setTestResults(prev => [...prev, `CRUD test error: ${error instanceof Error ? error.message : String(error)}`]);
      
      toast({
        title: "Test error",
        description: `Error: ${error instanceof Error ? error.message : String(error)}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Head>
        <title>Supabase Test | Crystal Collector&apos;s Companion</title>
        <meta name="description" content="Test Supabase connection and functionality" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <h2 className="text-3xl font-bold mb-6">Supabase Connection Test</h2>
          
          <div className="max-w-3xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Connection Status</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <p>Supabase Connection:</p>
                  <div className="flex items-center">
                    {isConnected === null ? (
                      <span className="text-muted-foreground">Checking...</span>
                    ) : isConnected ? (
                      <span className="text-green-500 font-semibold">Connected</span>
                    ) : (
                      <span className="text-red-500 font-semibold">Disconnected</span>
                    )}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button 
                    onClick={checkConnection} 
                    disabled={isLoading}
                    className="bg-accent text-white hover:bg-accent/90"
                  >
                    {isLoading ? "Testing..." : "Test Connection"}
                  </Button>
                  
                  <Button 
                    onClick={runCreateTests} 
                    disabled={isLoading || !isConnected}
                    variant="outline"
                  >
                    Run CRUD Tests
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            {testResults.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Test Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-muted p-4 rounded-md max-h-80 overflow-y-auto">
                    <ul className="space-y-2">
                      {testResults.map((result, index) => (
                        <li key={index} className="font-mono text-sm">
                          {result}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            )}
            
            <Prospector 
              message="Testing connections is like checking your pickaxe before a dig - always a good idea!"
              className="mt-8"
            />
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}


import { Header } from "@/components/layout/Header";
import { Prospector } from "@/components/mascot/Prospector";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { SpecimenForm } from "@/components/specimens/SpecimenForm";
import { useRouter } from "next/router";
import { useState, useEffect } from "react";
import { Specimen } from "@/types/collection";

export default function EditSpecimen() {
  const router = useRouter();
  const { id } = router.query;
  const [specimen, setSpecimen] = useState<Specimen | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      // This would fetch the specimen from local storage or Supabase
      // For now, we'll use mock data
      setSpecimen({
        id: id as string,
        mineralName: "Amethyst",
        locality: "Thunder Bay, Ontario, Canada",
        acquisitionDate: "2023-05-15",
        photos: ["/placeholder-crystal.jpg"],
        pricePaid: 120,
        estimatedValue: 150,
        notes: "Beautiful deep purple cluster with excellent terminations.",
        mindatMineralLink: "https://www.mindat.org/min-198.html",
        mindatLocalityLink: "https://www.mindat.org/loc-3523.html",
        createdAt: "2023-05-15T12:00:00Z",
        updatedAt: "2023-05-15T12:00:00Z",
        collectionId: "main" // Added collectionId
      });
      setLoading(false);
    }
  }, [id]);

  const handleSave = () => {
    // This will be implemented when we connect to Supabase
    router.push(`/specimens/${id}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-8">
          <p>Loading...</p>
        </main>
      </div>
    );
  }

  if (!specimen) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-8">
          <p>Specimen not found</p>
        </main>
      </div>
    );
  }

  return (
    <>
      <Head>
        <title>Edit {specimen.mineralName} | Crystal Collector&apos;s Companion</title>
        <meta name="description" content={`Edit ${specimen.mineralName} specimen details`} />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <Prospector 
            category="tip"
            className="mb-8"
          />
          
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">Edit {specimen.mineralName}</h2>
            <SpecimenForm specimen={specimen} onSave={handleSave} />
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}

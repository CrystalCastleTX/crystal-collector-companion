import { Header } from "@/components/layout/Header";
import { Prospector } from "@/components/mascot/Prospector";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { useRouter } from "next/router";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { ShareButtons } from "@/components/sharing/ShareButtons";
import { Specimen } from "@/types/collection";

export default function SpecimenDetail() {
  const router = useRouter();
  const { id } = router.query;
  
  // Mock specimen data - would be fetched from local storage or Supabase
  const [specimen] = useState<Specimen>({
    id: typeof id === "string" ? id : "1",
    mineralName: "Amethyst",
    locality: "Thunder Bay, Ontario, Canada",
    acquisitionDate: "2023-05-15",
    photos: ["/placeholder-crystal.jpg"],
    pricePaid: 120,
    estimatedValue: 150,
    notes: "Beautiful deep purple cluster with excellent terminations.",
    mindatMineralLink: "https://www.mindat.org/min-198.html",
    mindatLocalityLink: "https://www.mindat.org/loc-3523.html",
    createdAt: "2023-05-15T12:00:00Z",
    updatedAt: "2023-05-15T12:00:00Z",
    collectionId: "main"
  });

  const handleDelete = () => {
    // This will be implemented when we connect to Supabase
    router.push("/collection");
  };

  return (
    <>
      <Head>
        <title>{specimen.mineralName} | Crystal Collector&apos;s Companion</title>
        <meta name="description" content={`Details for ${specimen.mineralName} specimen`} />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-bold">{specimen.mineralName}</h2>
              <div className="flex gap-2">
                <ShareButtons 
                  title={specimen.mineralName}
                  description={specimen.notes || `A beautiful ${specimen.mineralName} specimen from ${specimen.locality || 'my collection'}`}
                  url={typeof window !== "undefined" ? window.location.href : ""}
                  type="specimen"
                />
                <Link href={`/specimens/edit/${specimen.id}`} passHref>
                  <Button variant="outline">Edit</Button>
                </Link>
                <Button variant="destructive" onClick={handleDelete}>Delete</Button>
              </div>
            </div>
            
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    {specimen.photos.length > 0 ? (
                      <div className="aspect-square relative rounded-md overflow-hidden">
                        <Image 
                          src={specimen.photos[0]} 
                          alt={specimen.mineralName}
                          fill
                          className="object-cover"
                        />
                      </div>
                    ) : (
                      <div className="aspect-square bg-muted flex items-center justify-center rounded-md">
                        <p className="text-muted-foreground">No image available</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-4">
                    {specimen.locality && (
                      <div>
                        <h3 className="text-lg font-semibold">Locality</h3>
                        <p>{specimen.locality}</p>
                      </div>
                    )}
                    
                    {specimen.acquisitionDate && (
                      <div>
                        <h3 className="text-lg font-semibold">Acquisition Date</h3>
                        <p>{new Date(specimen.acquisitionDate).toLocaleDateString()}</p>
                      </div>
                    )}
                    
                    <div className="grid grid-cols-2 gap-4">
                      {specimen.pricePaid !== undefined && (
                        <div>
                          <h3 className="text-lg font-semibold">Price Paid</h3>
                          <p>${specimen.pricePaid.toFixed(2)}</p>
                        </div>
                      )}
                      
                      {specimen.estimatedValue !== undefined && (
                        <div>
                          <h3 className="text-lg font-semibold">Estimated Value</h3>
                          <p>${specimen.estimatedValue.toFixed(2)}</p>
                        </div>
                      )}
                    </div>
                    
                    <Separator />
                    
                    {specimen.notes && (
                      <div>
                        <h3 className="text-lg font-semibold">Notes</h3>
                        <p className="whitespace-pre-wrap">{specimen.notes}</p>
                      </div>
                    )}
                    
                    {(specimen.mindatMineralLink || specimen.mindatLocalityLink) && (
                      <div>
                        <h3 className="text-lg font-semibold">Mindat References</h3>
                        <div className="space-y-2">
                          {specimen.mindatMineralLink && (
                            <a 
                              href={specimen.mindatMineralLink} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="block text-foreground hover:underline"
                            >
                              View Mineral on Mindat.org
                            </a>
                          )}
                          {specimen.mindatLocalityLink && (
                            <a 
                              href={specimen.mindatLocalityLink} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="block text-foreground hover:underline"
                            >
                              View Locality on Mindat.org
                            </a>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Prospector 
              category="tip"
              className="mt-8"
            />
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}
import { Header } from "@/components/layout/Header";
import { Prospector } from "@/components/mascot/Prospector";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { SpecimenForm } from "@/components/specimens/SpecimenForm";
import { useRouter } from "next/router";

export default function AddSpecimen() {
  const router = useRouter();

  const handleSave = () => {
    // This will be implemented when we connect to Supabase
    router.push("/collection");
  };

  return (
    <>
      <Head>
        <title>Add Specimen | Crystal Collector&apos;s Companion</title>
        <meta name="description" content="Add a new specimen to your collection" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <Prospector 
            category="newSpecimen"
            className="mb-8"
          />
          
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold mb-6">Add New Specimen</h2>
            <SpecimenForm onSave={handleSave} />
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}
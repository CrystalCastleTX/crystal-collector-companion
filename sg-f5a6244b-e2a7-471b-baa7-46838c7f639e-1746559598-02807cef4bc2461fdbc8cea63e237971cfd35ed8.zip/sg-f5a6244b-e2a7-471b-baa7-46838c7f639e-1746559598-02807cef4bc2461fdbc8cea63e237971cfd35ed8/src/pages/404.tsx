
import React from "react";
import Head from "next/head";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import Image from "next/image";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

export default function NotFound() {
  return (
    <>
      <Head>
        <title>404 - Page Not Found | Crystal Collector&apos;s Companion</title>
        <meta name="description" content="Page not found" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      
      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 flex items-center justify-center px-4 py-12">
          <div className="max-w-2xl w-full text-center space-y-6">
            <h1 className="text-6xl font-bold text-foreground">404</h1>
            <p className="text-xl text-foreground">Looks like you've wandered off the map!</p>
            <p className="text-lg text-muted-foreground">The page you're looking for has been moved, deleted, or might be hiding in another crystal cave.</p>
            
            <div className="relative w-64 h-64 mx-auto my-8">
              <Image 
                src="/chatgpt-image-apr-23-2025-05-12-36-pm-macxbkyw.png"
                alt="The Prospector sitting by crystals"
                fill
                className="object-contain"
              />
            </div>
            
            <p className="text-lg text-foreground italic">"Even the best prospectors take a wrong turn now and then. Let's get you back on the right path!"</p>
            
            <Button asChild size="lg" className="mt-4">
              <Link href="/">
                Return to Home
              </Link>
            </Button>
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}

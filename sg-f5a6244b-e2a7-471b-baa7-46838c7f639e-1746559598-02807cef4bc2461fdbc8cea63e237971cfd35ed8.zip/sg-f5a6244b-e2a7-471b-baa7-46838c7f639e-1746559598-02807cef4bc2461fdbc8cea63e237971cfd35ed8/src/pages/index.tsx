
import { Header } from "@/components/layout/Header";
import { Prospector } from "@/components/mascot/Prospector";
import { Button } from "@/components/ui/button";
import { GoogleSignIn } from "@/components/auth/GoogleSignIn";
import { CollectionView } from "@/components/collection/CollectionView";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { useState } from "react";
import { User } from "@/types/collection";
import Image from "next/image";
import Link from "next/link";

export default function Home() {
  const [user, setUser] = useState<User | null>(null);

  const handleSignIn = (userData: User) => {
    setUser(userData);
  };

  return (
    <>
      <Head>
        <title>Collector&apos;s Companion</title>
        <meta name="description" content="Catalog and manage your crystal collection" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          {!user ? (
            <div className="text-center space-y-6">
              <div className="relative w-64 h-64 mx-auto mb-8">
                <Image
                  src="/chatgpt-image-may-6-2025-04-21-54-pm-mad0m1mb.png"
                  alt="Crystal Cluster"
                  fill
                  className="object-contain"
                />
              </div>
              
              <h2 className="text-4xl font-bold text-foreground">
                Welcome to your digital mineral collection!
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Catalog, organize, and manage your personal fine mineral collection with ease.
                Get started by signing in to create your digital collection.
              </p>
              <div className="flex justify-center gap-4">
                <GoogleSignIn onSignIn={handleSignIn} />
                <Link href="/about">
                  <Button variant="secondary" size="lg">
                    Learn More
                  </Button>
                </Link>
              </div>
              
              <Prospector 
                category="launch"
                className="mt-10"
              />
            </div>
          ) : (
            <CollectionView 
              specimens={[]} 
              onExport={() => console.log("Export collection")}
              className="mt-8"
            />
          )}
        </main>
        
        <Footer />
      </div>
    </>
  );
}

import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { Toaster } from "@/components/ui/toaster";
import { useEffect } from "react";

export default function App({ Component, pageProps }: AppProps) {
  useEffect(() => {
    // Set initial theme from localStorage or default to "classic"
    const savedTheme = localStorage.getItem("theme") || "classic";
    document.documentElement.setAttribute("data-theme", savedTheme);
  }, []);

  return (
    <>
      <Component {...pageProps} />
      <Toaster />
    </>
  );
}
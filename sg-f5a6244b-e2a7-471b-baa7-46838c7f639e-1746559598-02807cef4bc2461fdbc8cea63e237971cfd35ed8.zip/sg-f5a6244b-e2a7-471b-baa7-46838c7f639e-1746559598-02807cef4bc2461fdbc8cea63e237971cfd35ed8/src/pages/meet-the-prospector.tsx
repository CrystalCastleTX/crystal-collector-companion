
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { Card, CardContent } from "@/components/ui/card";
import Image from "next/image";

export default function MeetTheProspector() {
  return (
    <>
      <Head>
        <title>Meet The Prospector | Crystal Collector&apos;s Companion</title>
        <meta name="description" content="Meet The Prospector, your guide to the world of fine minerals" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <div className="relative w-64 h-64 mx-auto mb-6">
                <Image
                  src="/chatgpt-image-may-6-2025-05-02-10-pm-mad2gup7.png"
                  alt="The Prospector"
                  fill
                  className="object-contain"
                />
              </div>
              <h1 className="text-4xl font-bold mb-4">Meet The Prospector</h1>
              <h2 className="text-2xl text-muted-foreground">Your Guide to the World of Fine Minerals</h2>
            </div>
            
            <Card>
              <CardContent className="p-8 space-y-6">
                <p className="text-lg">
                  Say hello to The Prospector — part mentor, part miner, and full-time crystal enthusiast. 
                  He&apos;s not just a character... he&apos;s a legend in the making, right there in your pocket.
                </p>

                <section className="space-y-4">
                  <h3 className="text-2xl font-bold flex items-center gap-2">
                    🪓 Who Is He?
                  </h3>
                  <p>
                    The Prospector is an old-school rockhound with a sharp eye for beauty, rarity, and value. 
                    He&apos;s spent his life trekking through dusty dig sites, mountain passes, and forgotten mines — 
                    not chasing gold, but chasing the story behind every specimen. He doesn&apos;t just know minerals; 
                    he feels them. Every layer, every locality, every luster — he&apos;s seen it all.
                  </p>
                </section>

                <section className="space-y-4">
                  <h3 className="text-2xl font-bold flex items-center gap-2">
                    📖 His Backstory
                  </h3>
                  <p>
                    Long before apps and algorithms, The Prospector kept his collection logged in a weathered old 
                    field notebook — dog-eared and dirt-stained from decades of discovery. He&apos;s catalogued fluorite 
                    in the dark, whispered to wulfenite, and once bartered a pack of gum for a pocket-sized gem 
                    that turned out to be world-class azurite.
                  </p>
                  <p>
                    But now, he&apos;s gone digital. And he&apos;s here to help you build a collection worth passing down.
                  </p>
                </section>

                <section className="space-y-4">
                  <h3 className="text-2xl font-bold flex items-center gap-2">
                    🔍 His Role in the App
                  </h3>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>He&apos;ll greet you when you log in</li>
                    <li>Offer tips when you&apos;re adding a new specimen</li>
                    <li>Crack jokes when you least expect it</li>
                    <li>And celebrate your milestones like the proud rockhound he is</li>
                  </ul>
                  <p>
                    Don&apos;t worry — he&apos;s not here to boss you around. He&apos;s here to make collecting fun, 
                    remind you to label your finds, and maybe teach you a thing or two along the way.
                  </p>
                </section>

                <section className="space-y-4">
                  <h3 className="text-2xl font-bold flex items-center gap-2">
                    ✨ Why He Matters
                  </h3>
                  <p>
                    The Prospector represents what collecting is really about:
                  </p>
                  <ul className="list-disc pl-6 space-y-2">
                    <li>Curiosity</li>
                    <li>Patience</li>
                    <li>A love for the story inside the stone</li>
                  </ul>
                  <p>
                    Whether you&apos;re logging your first amethyst or tracking a fine mineral collection decades 
                    in the making, he&apos;s your trusty companion.
                  </p>
                  <p className="italic">
                    So next time he pops up with a grin and a gleam in his eye, take a second to listen — 
                    he just might share a gem of his own.
                  </p>
                </section>
              </CardContent>
            </Card>
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}

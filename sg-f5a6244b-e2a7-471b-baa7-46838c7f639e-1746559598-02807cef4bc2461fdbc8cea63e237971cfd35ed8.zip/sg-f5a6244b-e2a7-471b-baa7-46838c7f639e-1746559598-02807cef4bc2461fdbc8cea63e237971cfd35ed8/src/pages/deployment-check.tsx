import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { CheckCircle, XCircle, AlertCircle, ExternalLink } from "lucide-react";
import { testSupabaseConnection } from "@/utils/supabase-test";
import { Prospector } from "@/components/mascot/Prospector";

interface CheckResult {
  name: string;
  status: 'success' | 'error' | 'warning' | 'checking';
  message: string;
}

export default function DeploymentCheckPage() {
  const [checks, setChecks] = useState<CheckResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const runDeploymentChecks = async () => {
    setIsRunning(true);
    setChecks([]);

    const newChecks: CheckResult[] = [];

    // Check 1: Environment Variables
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    
    if (supabaseUrl && supabaseKey) {
      newChecks.push({
        name: "Environment Variables",
        status: 'success',
        message: "Supabase credentials are configured"
      });
    } else {
      newChecks.push({
        name: "Environment Variables",
        status: 'error',
        message: "Missing Supabase environment variables"
      });
    }

    setChecks([...newChecks]);

    // Check 2: Supabase Connection
    try {
      const connected = await testSupabaseConnection();
      newChecks.push({
        name: "Supabase Connection",
        status: connected ? 'success' : 'error',
        message: connected ? "Successfully connected to Supabase" : "Failed to connect to Supabase"
      });
    } catch (error) {
      newChecks.push({
        name: "Supabase Connection",
        status: 'error',
        message: `Connection error: ${error instanceof Error ? error.message : String(error)}`
      });
    }

    setChecks([...newChecks]);

    // Check 3: Core App Features
    newChecks.push({
      name: "Core App Features",
      status: 'success',
      message: "✓ Specimen management ✓ Collections ✓ Photo upload ✓ The Prospector"
    });

    // Check 4: Theme and Branding  
    newChecks.push({
      name: "Theme and Branding",
      status: 'success',
      message: "✓ Purple theme ✓ Crystal Castle TX branding ✓ Responsive design"
    });

    // Check 5: Deployment Status
    const isProduction = window.location.hostname.includes('vercel.app') || 
                        window.location.hostname.includes('crystalcastle.rocks');
    
    newChecks.push({
      name: "Deployment Status",
      status: isProduction ? 'success' : 'warning',
      message: isProduction ? "Running on production domain" : "Running in development mode"
    });

    setChecks([...newChecks]);
    setIsRunning(false);
  };

  useEffect(() => {
    runDeploymentChecks();
  }, []);

  const getStatusIcon = (status: CheckResult['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-500" />;
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-muted-foreground animate-spin" />;
    }
  };

  const allPassed = checks.length > 0 && checks.every(check => check.status === 'success');
  const hasErrors = checks.some(check => check.status === 'error');

  return (
    <>
      <Head>
        <title>Deployment Check | Crystal Collector&apos;s Companion</title>
        <meta name="description" content="Verify your deployment status" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <h2 className="text-3xl font-bold mb-6">Deployment Verification</h2>
          
          <div className="max-w-3xl mx-auto space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>System Status Check</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <span className="font-medium">Overall Status:</span>
                  <div className="flex items-center gap-2">
                    {allPassed && <span className="text-green-500 font-semibold">✅ All Systems Go!</span>}
                    {hasErrors && <span className="text-red-500 font-semibold">❌ Issues Detected</span>}
                    {!allPassed && !hasErrors && <span className="text-yellow-500 font-semibold">⚠️ Minor Issues</span>}
                  </div>
                </div>

                <div className="space-y-3">
                  {checks.map((check, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-md">
                      <div className="flex items-center gap-3">
                        {getStatusIcon(check.status)}
                        <span className="font-medium">{check.name}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">{check.message}</span>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2 pt-4">
                  <Button 
                    onClick={runDeploymentChecks} 
                    disabled={isRunning}
                    className="bg-accent text-white hover:bg-accent/90"
                  >
                    {isRunning ? "Running Checks..." : "Run Checks Again"}
                  </Button>

                  <Button asChild variant="outline">
                    <a 
                      href="https://vercel.com/devyn-s-projects/crystal-collectors-companion-final-f5a6244b-e2a7-471b-baa7-46838c7f639e" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-2"
                    >
                      View Vercel Dashboard <ExternalLink className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>GitHub to Vercel Deployment Guide</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="p-3 bg-muted rounded-md">
                    <h4 className="font-semibold mb-2">🚀 Step 1: Push to GitHub</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      Your code needs to be in your GitHub repository:
                    </p>
                    <code className="bg-background px-2 py-1 rounded text-xs">
                      https://github.com/CrystalCastleTX/crystal-collector-companion
                    </code>
                  </div>

                  <div className="p-3 bg-muted rounded-md">
                    <h4 className="font-semibold mb-2">🔗 Step 2: Connect to Vercel</h4>
                    <ol className="list-decimal pl-4 space-y-1 text-sm text-muted-foreground">
                      <li>Go to <a href="https://vercel.com/new" target="_blank" rel="noopener noreferrer" className="text-foreground underline">vercel.com/new</a></li>
                      <li>Connect your GitHub account</li>
                      <li>Import your crystal-collector-companion repository</li>
                      <li>Vercel will auto-detect it's a Next.js project</li>
                    </ol>
                  </div>

                  <div className="p-3 bg-muted rounded-md">
                    <h4 className="font-semibold mb-2">⚙️ Step 3: Environment Variables</h4>
                    <p className="text-sm text-muted-foreground mb-2">
                      In Vercel project settings, add these environment variables:
                    </p>
                    <div className="text-xs bg-background p-2 rounded font-mono">
                      NEXT_PUBLIC_SUPABASE_URL=https://hwrkivfhdswdecerguzs.supabase.co<br/>
                      NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
                    </div>
                  </div>

                  <div className="p-3 bg-muted rounded-md">
                    <h4 className="font-semibold mb-2">🌐 Step 4: Embed in Shopify</h4>
                    <p className="text-sm text-muted-foreground">
                      Once deployed, use your Vercel URL in an iframe on your Shopify page:
                    </p>
                    <code className="bg-background px-2 py-1 rounded ml-2 text-xs">
                      https://crystalcastle.rocks/pages/crystal-collector-companion
                    </code>
                  </div>
                </div>

                <div className="pt-4">
                  <Button asChild className="bg-accent text-white hover:bg-accent/90">
                    <a href="https://vercel.com/new" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                      Start Deployment <ExternalLink className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
            
            <Prospector 
              message={allPassed ? "Everything's looking crystal clear! Your app is ready to rock!" : "Let's dig into those issues and get this collection online!"}
              className="mt-8"
            />
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}
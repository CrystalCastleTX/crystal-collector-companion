
import { Header } from "@/components/layout/Header";
import { Prospector } from "@/components/mascot/Prospector";
import { Footer } from "@/components/layout/Footer";
import Head from "next/head";
import { CollectionView } from "@/components/collection/CollectionView";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { useState, useEffect } from "react";
import { Specimen, Collection } from "@/types/collection";
import { useRouter } from "next/router";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from "@/components/ui/breadcrumb";
import { Folder } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function CollectionPage() {
  const router = useRouter();
  const { id } = router.query;
  
  const [specimens, setSpecimens] = useState<Specimen[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [currentCollection, setCurrentCollection] = useState<Collection | null>(null);
  const [breadcrumbs, setBreadcrumbs] = useState<Collection[]>([]);
  
  useEffect(() => {
    // Mock data setup
    const mockSpecimens: Specimen[] = [
      {
        id: "1",
        mineralName: "Amethyst",
        locality: "Thunder Bay, Ontario, Canada",
        acquisitionDate: "2023-05-15",
        photos: ["/placeholder-crystal.jpg"],
        pricePaid: 120,
        estimatedValue: 150,
        notes: "Beautiful deep purple cluster with excellent terminations.",
        mindatMineralLink: "https://www.mindat.org/min-198.html",
        mindatLocalityLink: "https://www.mindat.org/loc-3523.html",
        createdAt: "2023-05-15T12:00:00Z",
        updatedAt: "2023-05-15T12:00:00Z",
        collectionId: "main"
      },
      {
        id: "2",
        mineralName: "Fluorite",
        locality: "Rogerley Mine, England",
        acquisitionDate: "2023-06-20",
        photos: ["/placeholder-crystal.jpg"],
        pricePaid: 85,
        estimatedValue: 100,
        notes: "Green cubic crystals with purple phantoms.",
        mindatMineralLink: "https://www.mindat.org/min-1576.html",
        mindatLocalityLink: "https://www.mindat.org/loc-3523.html",
        createdAt: "2023-06-20T12:00:00Z",
        updatedAt: "2023-06-20T12:00:00Z",
        collectionId: "main"
      }
    ];

    const mockCollections: Collection[] = [
      {
        id: "main",
        name: "My Collection",
        specimens: ["1", "2"],
        subCollections: ["sub1", "sub2"],
        lastUpdated: "2023-06-20T12:00:00Z",
        userId: "user1"
      },
      {
        id: "sub1",
        name: "Quartz Varieties",
        parentId: "main",
        specimens: [],
        subCollections: [],
        lastUpdated: "2023-06-20T12:00:00Z",
        userId: "user1"
      },
      {
        id: "sub2",
        name: "Fluorite Collection",
        parentId: "main",
        specimens: [],
        subCollections: [],
        lastUpdated: "2023-06-20T12:00:00Z",
        userId: "user1"
      }
    ];

    setCollections(mockCollections);
    const collectionId = id as string || "main";
    const collection = mockCollections.find(c => c.id === collectionId) || mockCollections[0];
    setCurrentCollection(collection);
    const collectionSpecimens = mockSpecimens.filter(s => s.collectionId === collectionId);
    setSpecimens(collectionSpecimens);
    
    const buildBreadcrumbs = (collectionId: string): Collection[] => {
      const collection = mockCollections.find(c => c.id === collectionId);
      if (!collection) return [];
      if (collection.parentId) {
        return [...buildBreadcrumbs(collection.parentId), collection];
      }
      return [collection];
    };
    
    setBreadcrumbs(buildBreadcrumbs(collectionId));
  }, [id]);

  const handleExport = () => {
    console.log("Export collection");
  };

  const handleRenameCollection = (newName: string) => {
    if (currentCollection) {
      const updatedCollection = { ...currentCollection, name: newName };
      setCurrentCollection(updatedCollection);
      const updatedCollections = collections.map(c => 
        c.id === currentCollection.id ? updatedCollection : c
      );
      setCollections(updatedCollections);
    }
  };

  const handleCreateSubCollection = (name: string) => {
    if (currentCollection) {
      const newId = `sub${collections.length + 1}`;
      const newCollection: Collection = {
        id: newId,
        name,
        parentId: currentCollection.id,
        specimens: [],
        subCollections: [],
        lastUpdated: new Date().toISOString(),
        userId: "user1"
      };
      
      const updatedCollections = [...collections, newCollection];
      setCollections(updatedCollections);
      const updatedParent = { 
        ...currentCollection, 
        subCollections: [...currentCollection.subCollections, newId] 
      };
      setCurrentCollection(updatedParent);
      const finalCollections = updatedCollections.map(c => 
        c.id === currentCollection.id ? updatedParent : c
      );
      setCollections(finalCollections);
    }
  };

  if (!currentCollection) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-8">
          <p>Loading...</p>
        </main>
        <Footer />
      </div>
    );
  }

  const subCollections = collections.filter(c => 
    currentCollection.subCollections.includes(c.id)
  );

  return (
    <>
      <Head>
        <title>{currentCollection.name} | Crystal Collector&apos;s Companion</title>
        <meta name="description" content="View and manage your crystal collection" />
      </Head>

      <div className="min-h-screen flex flex-col">
        <Header />
        
        <main className="flex-1 container mx-auto px-4 py-8">
          <div className="max-w-7xl mx-auto">
            <div className="mb-6">
              <Breadcrumb>
                <BreadcrumbList>
                  <BreadcrumbItem>
                    <BreadcrumbLink href="/collection">Collections</BreadcrumbLink>
                  </BreadcrumbItem>
                  {breadcrumbs.slice(0, -1).map((crumb) => (
                    <BreadcrumbItem key={crumb.id}>
                      <BreadcrumbSeparator />
                      <BreadcrumbLink href={`/collection?id=${crumb.id}`}>
                        {crumb.name}
                      </BreadcrumbLink>
                    </BreadcrumbItem>
                  ))}
                  {breadcrumbs.length > 0 && (
                    <BreadcrumbItem>
                      <BreadcrumbSeparator />
                      <BreadcrumbLink>
                        {currentCollection.name}
                      </BreadcrumbLink>
                    </BreadcrumbItem>
                  )}
                </BreadcrumbList>
              </Breadcrumb>
            </div>
            
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-bold">Collection Manager</h2>
              <Link href="/specimens/add" passHref>
                <Button className="bg-accent text-white hover:bg-accent/90">Add Specimen</Button>
              </Link>
            </div>
            
            <div className="space-y-8">
              <CollectionView 
                specimens={specimens} 
                onExport={handleExport}
                collectionName={currentCollection.name}
                onRenameCollection={handleRenameCollection}
                onCreateSubCollection={handleCreateSubCollection}
              />
              
              {subCollections.length > 0 && (
                <div>
                  <h3 className="text-xl font-semibold mb-4">Sub-Collections</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {subCollections.map((collection) => (
                      <Link 
                        href={`/collection?id=${collection.id}`} 
                        key={collection.id}
                        passHref
                      >
                        <Card className="cursor-pointer hover:shadow-md transition-shadow">
                          <CardHeader className="pb-2">
                            <CardTitle className="flex items-center">
                              <Folder className="h-5 w-5 mr-2" />
                              {collection.name}
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <p className="text-sm text-muted-foreground">
                              {collection.specimens.length} specimens
                            </p>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
              
              <Prospector 
                category={specimens.length >= 10 ? "milestone" : "launch"}
                className="mt-8"
              />
            </div>
          </div>
        </main>
        
        <Footer />
      </div>
    </>
  );
}

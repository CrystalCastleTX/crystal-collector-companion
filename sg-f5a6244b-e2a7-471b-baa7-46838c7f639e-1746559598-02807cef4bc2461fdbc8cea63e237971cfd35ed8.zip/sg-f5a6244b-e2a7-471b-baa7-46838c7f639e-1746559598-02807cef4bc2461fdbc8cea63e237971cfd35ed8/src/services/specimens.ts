
import { supabase } from '@/lib/supabase';
import { Specimen } from '@/types/collection';

export const specimenService = {
  async getSpecimens(collectionId: string) {
    const { data, error } = await supabase
      .from('specimens')
      .select('*')
      .eq('collection_id', collectionId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as Specimen[];
  },

  async getSpecimen(id: string) {
    const { data, error } = await supabase
      .from('specimens')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data as Specimen;
  },

  async createSpecimen(specimen: Partial<Specimen>) {
    const { data, error } = await supabase
      .from('specimens')
      .insert([specimen])
      .select()
      .single();

    if (error) throw error;
    return data as Specimen;
  },

  async updateSpecimen(id: string, updates: Partial<Specimen>) {
    const { data, error } = await supabase
      .from('specimens')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data as Specimen;
  },

  async deleteSpecimen(id: string) {
    const { error } = await supabase
      .from('specimens')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async uploadPhoto(file: File, path: string) {
    const { data, error } = await supabase.storage
      .from('specimen-photos')
      .upload(path, file);

    if (error) throw error;
    return data;
  },

  async deletePhoto(path: string) {
    const { error } = await supabase.storage
      .from('specimen-photos')
      .remove([path]);

    if (error) throw error;
  }
};

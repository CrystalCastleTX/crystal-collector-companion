
import { supabase } from '@/lib/supabase';
import { Collection } from '@/types/collection';

export const collectionService = {
  async getCollections(userId: string) {
    const { data, error } = await supabase
      .from('collections')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data as Collection[];
  },

  async getCollection(id: string) {
    const { data, error } = await supabase
      .from('collections')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data as Collection;
  },

  async createCollection(collection: Partial<Collection>) {
    const { data, error } = await supabase
      .from('collections')
      .insert([collection])
      .select()
      .single();

    if (error) throw error;
    return data as Collection;
  },

  async updateCollection(id: string, updates: Partial<Collection>) {
    const { data, error } = await supabase
      .from('collections')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data as Collection;
  },

  async deleteCollection(id: string) {
    const { error } = await supabase
      .from('collections')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
};

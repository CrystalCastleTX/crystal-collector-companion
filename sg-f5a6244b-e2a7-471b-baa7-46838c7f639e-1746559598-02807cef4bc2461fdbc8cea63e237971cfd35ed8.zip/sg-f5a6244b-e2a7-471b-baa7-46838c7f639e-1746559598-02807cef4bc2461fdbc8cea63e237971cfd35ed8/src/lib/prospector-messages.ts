
export type MessageCategory = "launch" | "newSpecimen" | "milestone" | "tip" | "joke" | "export";

interface ProspectorMessage {
  text: string;
  category: MessageCategory;
}

export const prospectorMessages: ProspectorMessage[] = [
  // Launch Messages
  {
    text: "Welcome back, collector! Let's see what treasures you've been logging.",
    category: "launch"
  },
  {
    text: "Back for more? You're just one rock away from greatness.",
    category: "launch"
  },
  {
    text: "Good to see you again — your collection's shaping up real nice!",
    category: "launch"
  },

  // New Specimen Messages
  {
    text: "That's a fine piece you've got there! Don't forget to note where it came from.",
    category: "newSpecimen"
  },
  {
    text: "Another one for the vault! Keep 'em coming.",
    category: "newSpecimen"
  },
  {
    text: "A new entry? You're making history — one mineral at a time.",
    category: "newSpecimen"
  },

  // Milestone Messages
  {
    text: "Double digits! You're building a museum in your pocket.",
    category: "milestone"
  },
  {
    text: "This isn't a collection anymore — this is a legacy.",
    category: "milestone"
  },
  {
    text: "Whoa! That shelf's gettin' full. Got room for one more?",
    category: "milestone"
  },

  // Tips
  {
    text: "Label your minerals now — future you will thank you.",
    category: "tip"
  },
  {
    text: "Pro tip: Keep locality info sharp. It makes all the difference.",
    category: "tip"
  },
  {
    text: "A good collector always knows where it came from, not just what it is.",
    category: "tip"
  },

  // Jokes
  {
    text: "Why was the quartz single? It couldn't find a crystal-clear relationship.",
    category: "joke"
  },
  {
    text: "Rock collecting: the only hobby where being grounded is a good thing.",
    category: "joke"
  },
  {
    text: "Fluorite comes in more colors than a candy shop. Tasty, but don't eat it.",
    category: "joke"
  },
  {
    text: "Every specimen's got a story. Yours? Might just be a bestseller.",
    category: "joke"
  },

  // Export Messages
  {
    text: "Showing off your stash? Make sure it's lookin' sharp!",
    category: "export"
  },
  {
    text: "Emailing your collection? You fancy now!",
    category: "export"
  }
];

export function getRandomMessage(category: MessageCategory): string {
  const messagesInCategory = prospectorMessages.filter(msg => msg.category === category);
  const randomIndex = Math.floor(Math.random() * messagesInCategory.length);
  return messagesInCategory[randomIndex].text;
}

export function getRandomTipOrJoke(): string {
  const tipsAndJokes = prospectorMessages.filter(msg => msg.category === "tip" || msg.category === "joke");
  const randomIndex = Math.floor(Math.random() * tipsAndJokes.length);
  return tipsAndJokes[randomIndex].text;
}

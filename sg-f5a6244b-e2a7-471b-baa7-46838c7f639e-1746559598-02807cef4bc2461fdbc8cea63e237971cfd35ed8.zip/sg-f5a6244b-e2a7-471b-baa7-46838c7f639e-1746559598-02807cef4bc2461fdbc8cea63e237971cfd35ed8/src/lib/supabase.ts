
import { createClient } from '@supabase/supabase-js';

// Mock Supabase client for development
const createMockClient = () => {
  return {
    auth: {
      signInWithOAuth: async () => ({ data: {}, error: null }),
      signOut: async () => ({ error: null }),
      getUser: async () => ({ data: { user: null }, error: null }),
      onAuthStateChange: (callback: any) => {
        // Return a mock unsubscribe function
        return { data: { subscription: { unsubscribe: () => {} } } };
      }
    },
    from: (table: string) => ({
      select: (query?: string) => ({
        eq: (column: string, value: any) => ({
          order: (column: string, { ascending }: { ascending: boolean }) => ({
            then: async () => [],
          }),
          single: async () => ({ data: null, error: null }),
          then: async () => ({ data: [], error: null }),
        }),
      }),
      insert: (data: any) => ({
        select: () => ({
          single: async () => ({ data: { ...data[0], id: 'mock-id' }, error: null }),
        }),
      }),
      update: (data: any) => ({
        eq: (column: string, value: any) => ({
          select: () => ({
            single: async () => ({ data: { ...data, id: value }, error: null }),
          }),
        }),
      }),
      delete: () => ({
        eq: (column: string, value: any) => ({
          then: async () => ({ error: null }),
        }),
      }),
    }),
    storage: {
      from: (bucket: string) => ({
        upload: async (path: string, file: File) => ({ data: { path }, error: null }),
        remove: async (paths: string[]) => ({ error: null }),
        getBucket: async () => ({ data: { name: bucket }, error: null }),
      }),
      getBucket: async (name: string) => ({ data: { name }, error: null }),
    },
  };
};

// Try to use environment variables if available, otherwise use mock client
let supabase: any;

try {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (supabaseUrl && supabaseAnonKey) {
    supabase = createClient(supabaseUrl, supabaseAnonKey);
    console.log('Using real Supabase client with URL:', supabaseUrl);
  } else {
    supabase = createMockClient();
    console.warn('No Supabase credentials found, using mock client');
  }
} catch (error) {
  console.error('Error initializing Supabase client:', error);
  console.warn('Falling back to mock client');
  supabase = createMockClient();
}

// Test the connection
supabase.from('collections').select('count', { count: 'exact', head: true })
  .then(() => console.log('Successfully connected to Supabase'))
  .catch((err: Error) => console.error('Error connecting to Supabase:', err));

export { supabase };

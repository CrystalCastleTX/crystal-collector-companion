import { supabase } from '@/lib/supabase';
import { Collection, Specimen } from '@/types/collection';

export async function testSupabaseConnection() {
  try {
    // Test collections table
    const { data: collections, error: collectionsError } = await supabase
      .from('collections')
      .select('*')
      .limit(1);
    
    if (collectionsError) throw collectionsError;
    console.log('Collections table accessible:', collections);

    // Test specimens table
    const { data: specimens, error: specimensError } = await supabase
      .from('specimens')
      .select('*')
      .limit(1);
    
    if (specimensError) throw specimensError;
    console.log('Specimens table accessible:', specimens);

    // Test storage bucket
    const { data: bucket, error: bucketError } = await supabase
      .storage
      .getBucket('specimen-photos');
    
    if (bucketError) throw bucketError;
    console.log('Storage bucket accessible:', bucket);

    return true;
  } catch (error) {
    console.error('Supabase connection test failed:', error);
    return false;
  }
}

export async function testCreateCollection(userId: string): Promise<Collection | null> {
  try {
    const { data, error } = await supabase
      .from('collections')
      .insert([{
        name: 'Test Collection',
        description: 'Testing Supabase connection',
        user_id: userId
      }])
      .select()
      .single();

    if (error) throw error;
    console.log('Successfully created test collection:', data);
    return data;
  } catch (error) {
    console.error('Error creating test collection:', error);
    return null;
  }
}

export async function testCreateSpecimen(collectionId: string, userId: string): Promise<Specimen | null> {
  try {
    const { data, error } = await supabase
      .from('specimens')
      .insert([{
        mineral_name: 'Test Specimen',
        locality: 'Test Location',
        collection_id: collectionId,
        user_id: userId
      }])
      .select()
      .single();

    if (error) throw error;
    console.log('Successfully created test specimen:', data);
    return data as any; // Type assertion to handle DB vs client model differences
  } catch (error) {
    console.error('Error creating test specimen:', error);
    return null;
  }
}
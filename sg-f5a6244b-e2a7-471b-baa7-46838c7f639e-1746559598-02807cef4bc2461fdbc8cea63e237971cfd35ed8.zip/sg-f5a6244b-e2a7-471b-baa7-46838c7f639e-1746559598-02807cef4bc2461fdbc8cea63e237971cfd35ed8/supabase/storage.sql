
-- Create storage bucket for specimen photos if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
SELECT 'specimen-photos', 'specimen-photos', true
WHERE NOT EXISTS (
    SELECT 1 FROM storage.buckets WHERE id = 'specimen-photos'
);

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view any specimen photo" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload their own specimen photos" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their own specimen photos" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own specimen photos" ON storage.objects;

-- Create storage policies
CREATE POLICY "Users can view any specimen photo"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'specimen-photos');

CREATE POLICY "Users can upload their own specimen photos"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'specimen-photos' 
    AND auth.uid() = owner
  );

CREATE POLICY "Users can update their own specimen photos"
  ON storage.objects FOR UPDATE
  USING (
    bucket_id = 'specimen-photos' 
    AND auth.uid() = owner
  );

CREATE POLICY "Users can delete their own specimen photos"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'specimen-photos' 
    AND auth.uid() = owner
  );
